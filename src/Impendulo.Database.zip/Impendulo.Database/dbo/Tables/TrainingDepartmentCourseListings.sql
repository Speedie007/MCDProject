﻿CREATE TABLE [dbo].[TrainingDepartmentCourseListings] (
    [TrainingDepartmentCourseID]         INT NOT NULL,
    [TrainingDepartmentCourseMetaDataID] INT NOT NULL,
    CONSTRAINT [PK_TrainingDepartmentCourseListings] PRIMARY KEY CLUSTERED ([TrainingDepartmentCourseID] ASC, [TrainingDepartmentCourseMetaDataID] ASC),
    CONSTRAINT [FK_TrainingDepartmentCourseCompisitions_TrainingDepartmentIndividualCourses] FOREIGN KEY ([TrainingDepartmentCourseMetaDataID]) REFERENCES [dbo].[TrainingDepartmentCourseMetaData] ([TrainingDepartmentCourseMetaDataID]),
    CONSTRAINT [FK_TrainingDepartmentCourseListings_TrainingDepartmentCourses] FOREIGN KEY ([TrainingDepartmentCourseID]) REFERENCES [dbo].[TrainingDepartmentCourses] ([TrainingDepartmentCourseID])
);



