﻿CREATE TABLE [dbo].[TrainingDepartmentCourseEnrollmentTypeModuleActivities] (
    [TrainingDepartmentCourseEnrollmentTypeModuleActivityID] INT NOT NULL,
    [ActivityID]                                             INT NOT NULL,
    CONSTRAINT [PK_TrainingDepartmentCourseEnrollmentTypeModuleActivities] PRIMARY KEY CLUSTERED ([TrainingDepartmentCourseEnrollmentTypeModuleActivityID] ASC, [ActivityID] ASC),
    CONSTRAINT [FK_TrainingDepartmentCourseEnrollmentTypeModuleActivities_Activities] FOREIGN KEY ([ActivityID]) REFERENCES [dbo].[Activities] ([ActivityID]),
    CONSTRAINT [FK_TrainingDepartmentCourseEnrollmentTypeModuleActivities_TrainingDepartmentCourseEnrollmentTypeModules] FOREIGN KEY ([TrainingDepartmentCourseEnrollmentTypeModuleActivityID]) REFERENCES [dbo].[TrainingDepartmentCourseEnrollmentTypeModules] ([TrainingDepartmentCourseEnrollmentTypeModuleID])
);



