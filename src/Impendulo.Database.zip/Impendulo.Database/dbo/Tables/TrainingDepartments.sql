﻿CREATE TABLE [dbo].[TrainingDepartments] (
    [TrainingDepartmentID]   INT          IDENTITY (1, 1) NOT NULL,
    [DepartmentID]           INT          CONSTRAINT [DF_TrainingDepartments_DepartmentID] DEFAULT ((1)) NOT NULL,
    [TrainingDepartmentName] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Departments] PRIMARY KEY CLUSTERED ([TrainingDepartmentID] ASC),
    CONSTRAINT [FK_TrainingDepartments_Departments] FOREIGN KEY ([DepartmentID]) REFERENCES [dbo].[Departments] ([DepartmentID])
);





