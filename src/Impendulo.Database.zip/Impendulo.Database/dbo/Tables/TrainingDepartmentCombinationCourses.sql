




GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Creates a combination of Apprenticeship and Welders.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'TrainingDepartmentCourses', @level2type = N'CONSTRAINT', @level2name = N'FK_TrainingDepartmentCourses_TrainingDepartments';

