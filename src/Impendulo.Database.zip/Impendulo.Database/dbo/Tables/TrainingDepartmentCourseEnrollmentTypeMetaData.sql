﻿CREATE TABLE [dbo].[TrainingDepartmentCourseEnrollmentTypeMetaData] (
    [TrainingDepartmentCourseEnrollmentTypeMetaDataID] INT             IDENTITY (1, 1) NOT NULL,
    [TrainingDepartmentCourseMetaDataID]               INT             NOT NULL,
    [EnrollmentTypeID]                                 INT             CONSTRAINT [DF_TrainingDepartmentCourseEnrollmentTypeMetaData_EnrollmentTypeID] DEFAULT ((1)) NOT NULL,
    [TrainingDepartmentCourseMetaDataCourseDuration]   NCHAR (10)      CONSTRAINT [DF_TrainingDepartmentCourseEnrollmentTypeMetaData_TrainingDepartmentCourseMetaDataCourseDuration] DEFAULT ((1)) NULL,
    [TrainingDepartmentCourseMetaDataCourseCost]       DECIMAL (10, 2) CONSTRAINT [DF_TrainingDepartmentCourseEnrollmentTypeMetaData_TrainingDepartmentCourseMetaDataCourseCost] DEFAULT ((0.00)) NOT NULL,
    [TrainingDepartmentCourseMetaDataMaximunAllowed]   INT             CONSTRAINT [DF_TrainingDepartmentCourseEnrollmentTypeMetaData_TrainingDepartmentCourseMetaDataMaximunAllowed] DEFAULT ((9999)) NOT NULL,
    [TrainingDepartmentCourseMetaDataMinimunAllowed]   INT             CONSTRAINT [DF_TrainingDepartmentCourseEnrollmentTypeMetaData_TrainingDepartmentCourseMetaDataMinimunAllowed] DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_TrainingDepartmentCourseEnrollmentTypeMetaData] PRIMARY KEY CLUSTERED ([TrainingDepartmentCourseEnrollmentTypeMetaDataID] ASC),
    CONSTRAINT [FK_TrainingDepartmentCourseEnrollmentTypeMetaData_LookupEnrollmentTypes] FOREIGN KEY ([EnrollmentTypeID]) REFERENCES [dbo].[LookupEnrollmentTypes] ([EnrollmentTypeID]),
    CONSTRAINT [FK_TrainingDepartmentCourseEnrollmentTypeMetaData_TrainingDepartmentCourseMetaData] FOREIGN KEY ([TrainingDepartmentCourseMetaDataID]) REFERENCES [dbo].[TrainingDepartmentCourseMetaData] ([TrainingDepartmentCourseMetaDataID])
);

