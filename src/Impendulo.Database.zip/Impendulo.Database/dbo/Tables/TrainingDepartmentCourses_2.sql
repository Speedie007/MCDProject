﻿CREATE TABLE [dbo].[TrainingDepartmentCourses] (
    [TrainingDepartmentCourseID]   INT           IDENTITY (1, 1) NOT NULL,
    [TrainingDepartmentID]         INT           CONSTRAINT [DF_TrainingDepartmentCourses_TrainingDepartmentID] DEFAULT ((1)) NOT NULL,
    [TrainingDepartmentCourseName] VARCHAR (250) NULL,
    CONSTRAINT [PK_Courses] PRIMARY KEY CLUSTERED ([TrainingDepartmentCourseID] ASC),
    CONSTRAINT [FK_TrainingDepartmentCourses_TrainingDepartments] FOREIGN KEY ([TrainingDepartmentID]) REFERENCES [dbo].[TrainingDepartments] ([TrainingDepartmentID])
);

