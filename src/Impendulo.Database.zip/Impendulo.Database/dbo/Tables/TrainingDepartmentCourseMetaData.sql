﻿CREATE TABLE [dbo].[TrainingDepartmentCourseMetaData] (
    [TrainingDepartmentCourseMetaDataID]                INT           IDENTITY (1, 1) NOT NULL,
    [TrainingDepartmentID]                              INT           CONSTRAINT [DF_Courses_TrainingDepartmentID] DEFAULT ((1)) NOT NULL,
    [TrainingDepartmentCourseMetaDataCourseName]        VARCHAR (100) CONSTRAINT [DF_Courses_CourseName] DEFAULT ('Unknown') NOT NULL,
    [TrainingDepartmentCourseMetaDataCourseDescription] VARCHAR (500) CONSTRAINT [DF_Courses_CourseDescription] DEFAULT ('None') NOT NULL,
    CONSTRAINT [PK_Courses_1] PRIMARY KEY CLUSTERED ([TrainingDepartmentCourseMetaDataID] ASC),
    CONSTRAINT [FK_Courses_TrainingDepartments] FOREIGN KEY ([TrainingDepartmentID]) REFERENCES [dbo].[TrainingDepartments] ([TrainingDepartmentID])
);





