﻿CREATE TABLE [dbo].[OldModules] (
    [ModuleID]          INT            IDENTITY (1, 1) NOT NULL,
    [ModuleName]        VARCHAR (100)  NULL,
    [ModuleDescription] VARCHAR (2000) NULL,
    CONSTRAINT [PK_OldModules] PRIMARY KEY CLUSTERED ([ModuleID] ASC)
);

