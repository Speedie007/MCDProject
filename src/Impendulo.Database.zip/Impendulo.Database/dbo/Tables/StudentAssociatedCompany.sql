﻿CREATE TABLE [dbo].[StudentAssociatedCompany] (
    [IndividualID] INT NOT NULL,
    [CompanyID]    INT NOT NULL,
    CONSTRAINT [PK_StudentAssociatedCompany_1] PRIMARY KEY CLUSTERED ([IndividualID] ASC, [CompanyID] ASC),
    CONSTRAINT [FK_StudentAssociatedCompany_Companies] FOREIGN KEY ([CompanyID]) REFERENCES [dbo].[Companies] ([CompanyID]),
    CONSTRAINT [FK_StudentAssociatedCompany_Students] FOREIGN KEY ([IndividualID]) REFERENCES [dbo].[Students] ([IndividualID])
);





