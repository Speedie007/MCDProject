﻿CREATE TABLE [dbo].[TrainingDepartmentCourseEnrollmentTypeModules] (
    [TrainingDepartmentCourseEnrollmentTypeModuleID]   INT IDENTITY (1, 1) NOT NULL,
    [TrainingDepartmentCourseEnrollmentTypeMetaDataID] INT NOT NULL,
    [ModuleID]                                         INT NOT NULL,
    CONSTRAINT [PK_TrainingDepartmentCourseEnrollmentTypeModules] PRIMARY KEY CLUSTERED ([TrainingDepartmentCourseEnrollmentTypeModuleID] ASC),
    CONSTRAINT [FK_TrainingDepartmentCourseEnrollmentTypeModules_Modules] FOREIGN KEY ([ModuleID]) REFERENCES [dbo].[Modules] ([ModuleID]),
    CONSTRAINT [FK_TrainingDepartmentCourseEnrollmentTypeModules_TrainingDepartmentCourseEnrollmentTypeMetaData] FOREIGN KEY ([TrainingDepartmentCourseEnrollmentTypeMetaDataID]) REFERENCES [dbo].[TrainingDepartmentCourseEnrollmentTypeMetaData] ([TrainingDepartmentCourseEnrollmentTypeMetaDataID])
);

