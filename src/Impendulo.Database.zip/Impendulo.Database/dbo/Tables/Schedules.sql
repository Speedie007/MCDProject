﻿CREATE TABLE [dbo].[Schedules] (
    [ScheduleID]        INT  IDENTITY (1, 1) NOT NULL,
    [ScheduleStartDate] DATE CONSTRAINT [DF_Schedules_ScheduleStartDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Schedules] PRIMARY KEY CLUSTERED ([ScheduleID] ASC)
);

