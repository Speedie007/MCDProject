﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

/*Populates the Lookup Tables
******************************/

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupAddressTypes])
BEGIN
INSERT INTO [LookupAddressTypes]
           ([AddressType])
     VALUES
           ('Postal'),
		   ('Residential');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupContactTypes])
BEGIN
INSERT INTO [LookupContactTypes]
           ([ContactType])
     VALUES
           ('Email Address'),
		   ('Cell Number'),
		   ('Home Number');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupCountries])
BEGIN
INSERT INTO [LookupCountries]
           ([CountryName]
           ,[CountryCode])
     VALUES
           ('South Africa','ZAR'),
		   ('Lesotho','LS'),
		   ('Mozambique','MZ'),
		   ('Zimbabwe','ZW'),
		   ('Namibia','NA');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupDisabilities])
BEGIN
INSERT INTO [LookupDisabilities]
           ([Disability])
     VALUES
           ('Mobility Impairments'),
		   ('Physical Impairments'),
		   ('Vision'),
		   ('Hearing'),
		   ('Cognitive or Learning');
END;


IF NOT EXISTS (SELECT TOP 1 * FROM [LookupEthnicities])
BEGIN
INSERT INTO [LookupEthnicities]
           ([Ethnicity])
     VALUES
           ('Black African'),
		   ('White'),
		   ('Coloured'),
		   ('Indian'),
		   ('Asian'),
		   ('Other/Unspecified');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupGenders])
BEGIN
INSERT INTO  [LookupGenders]
           ([Gender])
     VALUES
           ('Male'),
		   ('Female');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupMartialStatuses])
BEGIN
INSERT INTO [LookupMartialStatuses]
           ([MaritialStatus])
     VALUES
           ('Married'),
		   ('Widowed'),
		   ('Separated'),
		   ('Divorced'),
		   ('Single');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupMartialStatuses])
BEGIN
INSERT INTO [LookupProvinces]
           ([Province])
     VALUES
           ('Eastern Cape'),
		   ('Free State'),
		   ('Gauteng'),
		   ('KwaZulu-Natal'),
		   ('Limpopo'),
		   ('Mpumalanga'),
		   ('Northern Cape'),
		   ('North West'),
		   ('Western Cape');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupQualificationLevels])
BEGIN
INSERT INTO [LookupQualificationLevels]
           ([QualificationLevel])
     VALUES
           ('NQF 1 (Grade 9/National Certificate)'),
		   ('NQF 2 (National Certificate)'),
		   ('NQF 3 (National Certificate)'),
		   ('NQF 4 (Grade 12/Matric)'),
		   ('NQF 5 (National Diplomas)'),
		   ('NQF 6 (National Diplomas)'),
		   ('NQF 7 (Bachelors Degree, B Techs, Advanced Diploma)'),
		   ('NQF 8 (Honours Degree/Post-graduate Diploma)'),
		   ('NQF 9 (Masters Degree)'),
		   ('NQF 10 (Doctrate)');
END;

IF NOT EXISTS (SELECT TOP 1 * FROM [LookupTitles])
BEGIN
INSERT INTO [LookupTitles]
           ([Title])
     VALUES
           ('Mr'),
		   ('Mrs'),
		   ('Miss'),
		   ('Dr'),
		   ('Prof');
END;

       







